#include <android/native_activity.h>
#include <android/log.h>
#include <binder/IServiceManager.h>
#include <media/IAudioFlinger.h>
#include <media/AudioTrack.h>  // For AudioTrack structure
#include <fcntl.h>
#include <unistd.h>

#define LOG_TAG "NativeAudioPlayer"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

using namespace android;

static void playAudioUsingHAL(const char* filePath) {
    // Get the AudioFlinger service
    sp<IBinder> binder = defaultServiceManager()->getService(String16("media.audio_flinger"));
    if (binder == nullptr) {
        LOGE("Failed to get AudioFlinger service");
        return;
    }

    sp<IAudioFlinger> audioFlinger = interface_cast<IAudioFlinger>(binder);
    if (audioFlinger == nullptr) {
        LOGE("Failed to cast AudioFlinger interface");
        return;
    }

    // Open the audio file
    int fd = open(filePath, O_RDONLY);
    if (fd < 0) {
        LOGE("Failed to open file: %s", filePath);
        return;
    }

    // Configure AudioTrack parameters
    AudioTrack track;
    track.mAttributes.contentType = AUDIO_CONTENT_TYPE_MUSIC;
    track.mAttributes.usage = AUDIO_USAGE_MEDIA;
    track.mAttributes.flags = AUDIO_FLAG_NONE;
    track.mSampleRate = 44100;  // Adjust based on your audio file
    track.mChannelMask = AUDIO_CHANNEL_OUT_STEREO;
    track.mFormat = AUDIO_FORMAT_PCM_16_BIT;

    // Create an audio track
    status_t status = audioFlinger->createTrack(
        0,                     // streamType (deprecated, use attributes)
        track.mAttributes,     // audio attributes
        track.mSampleRate,     // sample rate
        track.mChannelMask,    // channel mask
        track.mFormat,         // format
        0,                     // frameCount (0 for default)
        nullptr,               // callback
        nullptr,               // userData
        0,                     // notificationFrames
        nullptr,               // sharedBuffer
        false,                 // threadCanCallJava
        0,                     // sessionId
        &track.mTrack,         // output track
        nullptr                // output portId
    );

    if (status != NO_ERROR) {
        LOGE("Failed to create audio track: %d", status);
        close(fd);
        return;
    }

    // Write audio data to the track
    uint8_t buffer[4096];
    ssize_t bytesRead;
    while ((bytesRead = read(fd, buffer, sizeof(buffer))) > 0) {
        track.mTrack->write(buffer, bytesRead);
    }

    // Start playback
    track.mTrack->start();
    LOGI("Playing audio: %s", filePath);

    // Cleanup
    track.mTrack->stop();
    close(fd);
}

// Native activity entry point
void ANativeActivity_onCreate(ANativeActivity* activity, void* savedState, size_t savedStateSize) {
    LOGI("NativeAudioPlayer started");
    const char* filePath = "/sdcard/sample.mp3";  // Hardcoded for testing, adjust as needed
    playAudioUsingHAL(filePath);
    // Minimal activity: no UI, just trigger audio playback
}
